<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Words extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->output->enable_profiler();
	}
	public function index(){
		$this->load->view('word');
	}
	public function process_word(){
		if($this->session->userdata('counter')){
			$counter = $this->session->userdata('counter');
			$this->session->set_userdata('counter', ++$counter);
		} else{
			$this->session->set_userdata('counter', 1);
		}
		$word = '';
		for ($i = 0; $i < 14; $i++) {
		$word .= chr(mt_rand(65, 90));
		}
		$this->load->view('word', array('word' => $word, 'count' => $this->session->userdata('counter')));
	}
}