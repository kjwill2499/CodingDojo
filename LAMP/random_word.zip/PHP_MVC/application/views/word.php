<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Random Word Generator</title>
</head>
<body>
	<div>
		<h3>Random Word (attempt #<?=$count?>)</h3>
		<h2><?=$word?></h2>
		<form action=''>
			<input type="submit" value="Generate">
		</form>
	</div>
	
</body>
</html>