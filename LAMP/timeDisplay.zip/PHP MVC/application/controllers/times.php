<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Times extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->output->enable_profiler();
	}
	public function main(){
		$date = date('M d, Y');
		$time = date('h:i:s A');
		$view_data['time'] = array('calendar' => $date, 'clock' => $time);
		$this->load->view('time', $view_data);
	}
	public function hello(){
		echo "<p>Hello<p>";
	}
}
?>