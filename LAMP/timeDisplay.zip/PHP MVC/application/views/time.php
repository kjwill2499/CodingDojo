<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p>the current time and date is:</p>
	<div>
		<h2><?=$time['calendar']?></h2>
		<h2><?=$time['clock']?></h2>
	</div>
</body>
</html>