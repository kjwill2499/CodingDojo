<?php
session_start();
    $errors = array();
     //empty array to collect errors
    if(empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
    {
        $errors[] = "please enter a valid email";
    }
    if(empty($_POST['first']))
    {
        $errors[] = "first name cannot be blank";
    } 
    if(empty($_POST['last']))
    {
        $errors[] = "last name cannot be blank";
    } 
    if(empty($_POST['password']) || (strlen($_POST['password']) < 6))
    {
        $errors[] = "password must be at least 6 characters";
    } 
    if(empty($_POST['password_conf']) || ($_POST['password'] != $_POST['password_conf']))
    {
        $errors[] = "please confirm your password";
    } 
    if(count($errors) > 0)
    {
        //if there are errors, assign the session variable!
        $_SESSION['errors'] = $errors;
        header('location: index.php');
     }
     else
     {
        $_SESSION['success'] = "Your information was valid!";
        header('location: success.html');
    }
    if(!empty($_FILES['photo'])){
        $filepath = 'uploads/' . basename($_FILES['userfile']['photo']);
        move_uploaded_file($_FILES['userfile']['tmp_photo'], $filepath);
    } 

?>