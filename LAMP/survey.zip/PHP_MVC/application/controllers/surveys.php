<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Surveys extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->output->enable_profiler();
	}
	public function index(){
		$this->load->view('surveys/form');
	}
	public function process_form(){
		if($this->session->userdata('counter')){
			$counter = $this->session->userdata('counter');
			$this->session->set_userdata('counter', ++$counter);
		} else{
			$this->session->set_userdata('counter', 1);
		}
		$this->session->set_userdata(array('name' => $this->input->post('name'),
										'location' => $this->input->post('location'),
										'language' => $this->input->post('language'),
										'comment' => $this->input->post('comment')));
		redirect('/result');
	}
	public function result(){

		$this->load->view('surveys/result', $this->session->all_userdata());
	}
}