<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>CD Survey</title>
	<style type="text/css">
		div{
			width: 300px;
		}
		form input{
			display: block;
			width: 100%;
		}
		form select{
			display: inline-block;
		}
	</style>
</head>
<body>
	<div>
		<form action='surveys/process_form' method = 'post'>
			<input type='text' name='name' placeholder='Full Name'>
			Location:
			<select name='location'>
				<option value='Mountain View'>Mountain View</option>
				<option value='Seattle'>Seattle</option>
				<option value='Los Angeles'>Los Angeles</option>
				<option value='Dallas'>Dallas</option>
				<option value='New York'>New York</option>
				<option value='Philippines'>Philippines</option>
			</select>
			<br>
			Favorite Language:
			<select name='language'>
				<option value='Javascript'>Javascript</option>
				<option value='Node'>Node</option>
				<option value='Mango'>Mango</option>
				<option value='Ruby'>Ruby</option>
				<option value='Java'>Java</option>
				<option value='PHP'>PHP</option>
			</select>
			<textarea name='comment' placeholder='comments...'></textarea>
			<input type='submit'>
		</form>
	</div>
	
</body>
</html>