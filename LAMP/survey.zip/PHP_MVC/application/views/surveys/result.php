<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>CD Survey results</title>
</head>
<body>
	<div>
		<p>thanks for submitting this form, you have submitted this form <?=$counter?> times now.</p>
	</div>
	<div>
		<h3>Information Submitted:</h3>
		<table>
			<tr>
				<td>Name:</td>
				<td><?=$name?></td>
			</tr>
			<tr>
				<td>Location:</td>
				<td><?=$location?></td>
			</tr>
			<tr>
				<td>Favorite Language:</td>
				<td><?=$language?></td>
			</tr>
			<tr>
				<td>Comments:</td>
				<td><?=$comment?></td>
			</tr>
		</table>
		<form action='/' method ='post'>
			<input type='submit' value='Go Back'>
		</form>
		</form>
	</div>
	
</body>
</html>